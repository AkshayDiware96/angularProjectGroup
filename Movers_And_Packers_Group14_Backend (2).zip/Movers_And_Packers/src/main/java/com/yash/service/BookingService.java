package com.yash.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.model.Booking;
import com.yash.repository.BookingRepo;

@Service
public class BookingService {

	@Autowired
	private BookingRepo bookingrepo;
	
	public Booking saveBooking(Booking booking) {
		return bookingrepo.save(booking);
	}
	
	public Booking fetchUserName(String userName) {
		return bookingrepo.findByuserName(userName);
	}
	public Booking fetchConatact(String contact) {
		 return bookingrepo.findByconatact(contact);
	 }
	public Booking fetchFromCity(String fromCity) {
		return bookingrepo.findByfromCity(fromCity);
	}
	public Booking fetchToCity(String toCity) {
		return bookingrepo.findBytoCity(toCity);
	}
	
	public List<Booking> getAllBooking() {
		return bookingrepo.findAll();
	}

	public void deleteBooking(int userId) {
		
		bookingrepo.deleteById(userId);
		
	}
	
//	public String deleteBooking(int id) {
//		Optional<Booking> optionaluser= bookingrepo.findById(id);
//		if(optionaluser.isPresent()) {
//			bookingrepo.deleteById(id);
//			//System.out.println("Booking got deleted");
//			return "Booking got Deleted";
//		}else {
//			//System.out.println("Booking not present");
//			return "Booking not Present";
//		}
//	}
	
	
}
