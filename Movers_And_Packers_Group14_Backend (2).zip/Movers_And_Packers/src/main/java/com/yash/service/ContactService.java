package com.yash.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.model.ContactUs;
import com.yash.repository.ContactUsRepo;

@Service
public class ContactService {

	@Autowired
	private ContactUsRepo contactRepo;
	
	public ContactUs sendMessage(ContactUs contact) {
	
		return contactRepo.save(contact);
	}
	
	
}
