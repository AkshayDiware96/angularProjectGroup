//package com.yash.config;
//
//import org.springframework.context.annotation.Bean;
//
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.NoOpPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
//import org.springframework.security.web.csrf.CsrfTokenRepository;
//
//
//@Configuration
//@EnableWebSecurity
//public class MySecurityConfig extends WebSecurityConfigurerAdapter {
//	
//	@Override
//	protected void configure(HttpSecurity http)throws Exception{
//		
//			http
//					.csrf().csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
//					.and()
//					.authorizeRequests()
//					.antMatchers("/megha").permitAll()
//					.antMatchers("/bookingmap/**").hasAnyRole("ADMIN")
//					.antMatchers("/regis/**").hasAnyRole("NORMAL")
//					.anyRequest()
//					.authenticated()
//					.and()
//					.formLogin()
//					.loginPage("/megha")
//					.loginProcessingUrl("/dologin");	
//		
//	}
//	
//	
//	@Override
//	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
//		
//		auth.inMemoryAuthentication().withUser("yash").password(this.passwordEncoder().encode("yash@123")).roles("ADMIN");
//		
//		auth.inMemoryAuthentication().withUser("megha").password(this.passwordEncoder().encode("megha@123")).roles("NORMAL");
//	}
//	
//	
//	
//	@Bean
//	public PasswordEncoder passwordEncoder()
//	{
//		return new BCryptPasswordEncoder(10);
//	}
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//}
