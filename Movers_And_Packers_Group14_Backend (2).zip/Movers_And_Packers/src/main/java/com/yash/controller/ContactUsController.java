package com.yash.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.yash.model.ContactUs;
import com.yash.service.ContactService;

@RestController
public class ContactUsController {

	@Autowired
	private ContactService service;
	
	@PostMapping("/sendMessage")
	public ContactUs sendMessage(@RequestBody ContactUs contact) {
	
		return service.sendMessage(contact);
//		ContactUs contactObj=null;
//		contactObj=service.sendMessage(contact);
//		return contactObj;
	}
}
