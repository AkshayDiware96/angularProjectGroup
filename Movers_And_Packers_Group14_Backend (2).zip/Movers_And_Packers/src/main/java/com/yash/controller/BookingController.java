package com.yash.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.model.Booking;
import com.yash.service.BookingService;

@RestController
@CrossOrigin("*")
@RequestMapping("/bookingmap")
public class BookingController {
	
	
	private static final Logger log = LoggerFactory.getLogger(BookingController.class);

	@Autowired
	private BookingService bookservice;
	
	@PostMapping("/booking")
	//@CrossOrigin(origins= "http://localhost:4200")
	public Booking booking(@RequestBody Booking booking) throws Exception {
	
		log.info("Booking Model {}",booking);
		String tempuserName=booking.getUserName();
		String tempcontact=booking.getConatact();
		String tempfromCity=booking.getFromCity();
		String temptoCity=booking.getToCity();
		
//		
		/*
		 * if((tempuserName !=null && tempcontact!=null) && (tempfromCity !=null &&
		 * temptoCity!=null) ) { bookingObj=bookservice.saveBooking(booking); }
		 */
//		if((tempuserName ==null || tempcontact==null)) {
//			throw new Exception("Please Enter the all Fields");
//		}
//		if((tempfromCity !=null || temptoCity!=null)) {
//			throw new Exception("Please Enter the all Fields");
//		}
		/*
		 * if(bookingObj==null) { throw new Exception("Booking unsuccessfull!!!"); }
		 */
		Booking bookingObj = null;
		bookingObj=bookservice.saveBooking(booking);
		return bookingObj;
		
	}
	
	@GetMapping("/allrecords")
	@CrossOrigin(origins= "http://localhost:4200")
	public List<Booking> getAllBooking(){
		log.info("In method");
		return bookservice.getAllBooking();
	}
	
	@DeleteMapping("/deletebooking/{userId}")
	public String delete(@PathVariable("userId") int userId) {
		
		 bookservice.deleteBooking(userId);
		 
		 return "data is deleted";
	}
}
