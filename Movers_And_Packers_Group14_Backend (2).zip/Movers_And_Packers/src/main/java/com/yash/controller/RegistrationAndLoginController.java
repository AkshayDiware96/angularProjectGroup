package com.yash.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.model.Booking;
import com.yash.model.User;
import com.yash.service.RegistrationService;

@CrossOrigin("*")
@RestController
@RequestMapping("/regis")
public class RegistrationAndLoginController {

	
	private static final Logger log = LoggerFactory.getLogger(RegistrationAndLoginController.class);

	@Autowired
	private RegistrationService service;
	
	@PostMapping("/registeruser")
	public User registerUser(@RequestBody User user) throws Exception {
		log.info("In register method");
		String tempEmailId=user.getEmailId();
		
		if(tempEmailId != null && !"".equals(tempEmailId)) {
			User userObj=service.fetchUserByEmailId(tempEmailId);
			if(userObj != null) {
				throw new Exception("User with "+tempEmailId+" is already exist");
			}
		}
		User userObj=null;
		userObj=service.saveUser(user);
		return userObj;
	}
	
	@PostMapping("/login")
	public User loginUser(@RequestBody User user) throws Exception {
		log.info("In login method");
		String tempEmailId=user.getEmailId();
		String tempPassword=user.getPassword();
		User userObj=null;
		if(tempEmailId !=null && tempPassword !=null) {
			userObj=service.fetchUserByEmailIdAndPassword(tempEmailId, tempPassword);
		}
		if(userObj == null) {
			throw new Exception("Bad Credentials!!!!!!");
		}
		return userObj;
	}
	
	
	
	
	@GetMapping("/getAllUserData")
	public Iterable<User> getAllUserData()
	{
		log.info("Iterate All User method");
		Iterable<User> userlist =service.getAllUserData();
		return userlist;
		
	}
	
	
	
	
	
	

}
