package com.yash.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.model.Booking;

public interface BookingRepo extends JpaRepository<Booking, Integer>{

	public Booking findByuserName(String userName);
	public Booking findByconatact(String contact);
	public Booking findByfromCity(String fromCity);
	public Booking findBytoCity(String toCity);
//	public Booking deleteByBooking(Booking booking);
		
}
